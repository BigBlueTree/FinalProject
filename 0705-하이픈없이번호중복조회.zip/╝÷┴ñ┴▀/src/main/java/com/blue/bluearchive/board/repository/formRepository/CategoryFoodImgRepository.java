package com.blue.bluearchive.board.repository.formRepository;

import com.blue.bluearchive.board.entity.CategoryFoodImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryFoodImgRepository extends JpaRepository<CategoryFoodImg,Integer> {
}
