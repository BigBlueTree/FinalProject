package com.blue.bluearchive.constant;

public enum MemberStat {
    MEMBER,NOMEMBER,OUTMEMBER
}
