package com.blue.bluearchive.member.dto;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class MemberFormDto {
    @NotBlank(message = "이름은 필수 입력입니다.")
    private String name;

    @NotEmpty(message = "이메일은 필수 입력입니다.")
    @Email(message = "이메일 형식으로 입력해주세요.")
    private String email;

    @NotEmpty(message = "아이디는 필수 입력입니다.")
    private String id;

    @NotEmpty(message = "비밀번호는 필수 입력입니다.")
    @Pattern(regexp="^(?=.*\\d)(?=.*[!@#$%^&*])(?=.*[a-zA-Z]).{8,16}$", message = "비밀번호는 최소 8자리, 최대 16자리에 특수기호를 포함해야 합니다.")
    private String password;

    @NotEmpty(message = "주소는 필수 입력입니다.")
    private String address;

    @NotEmpty(message = "휴대전화번호는 필수 입력입니다.(-제외하고 입력)")
    @Pattern(regexp="^[0-9]{11}$", message="전화번호는 11자리 입니다 ex>xxx-xxxx-xxxx.")
    private String phoneNum;

    @NotEmpty(message = "별명은 필수 입력입니다.")
    private String nickName;
}
