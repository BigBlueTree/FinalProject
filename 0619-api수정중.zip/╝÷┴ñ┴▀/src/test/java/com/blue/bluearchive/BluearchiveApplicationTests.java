package com.blue.bluearchive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BluearchiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
