package com.blue.bluearchive.board.repository.formRepository;

import com.blue.bluearchive.board.entity.CategoryPlaceImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryPlaceImgRepository extends JpaRepository<CategoryPlaceImg,Integer> {
}
