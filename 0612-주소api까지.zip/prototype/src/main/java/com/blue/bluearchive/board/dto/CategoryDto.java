package com.blue.bluearchive.board.dto;

import lombok.Data;

@Data
public class CategoryDto {
    private int categoryId;
    private String categoryName;
}