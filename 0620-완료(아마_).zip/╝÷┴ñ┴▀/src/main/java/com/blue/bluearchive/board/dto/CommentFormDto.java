package com.blue.bluearchive.board.dto;


import com.blue.bluearchive.board.entity.Board;
import com.blue.bluearchive.board.entity.Comment;
import lombok.Data;
import org.modelmapper.ModelMapper;
import javax.validation.constraints.NotBlank;


@Data
public class CommentFormDto {
    @NotBlank(message = "내용은 필수 입니다")
    private String commentContent;
    private Board boardId;

    private static ModelMapper modelMapper = new ModelMapper();
    public Comment createBoard(){
        return modelMapper.map(this, Comment.class);
    }

    public static CommentFormDto of(Comment comment){
        return modelMapper.map(comment, CommentFormDto.class);
    }

}