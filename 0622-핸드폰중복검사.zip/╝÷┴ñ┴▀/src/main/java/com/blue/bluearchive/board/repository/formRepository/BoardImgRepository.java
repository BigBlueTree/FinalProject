package com.blue.bluearchive.board.repository.formRepository;

import com.blue.bluearchive.board.entity.BoardImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardImgRepository extends JpaRepository<BoardImg,Integer> {
}
