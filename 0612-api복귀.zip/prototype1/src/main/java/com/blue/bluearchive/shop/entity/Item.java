package com.blue.bluearchive.shop.entity;

import com.blue.bluearchive.constant.ItemSellStatus;
import com.blue.bluearchive.constant.ItemUseability;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="item")
@Getter
@Setter
@ToString
public class Item extends BaseEntity {
    @Id
    @Column(name = "item_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id; //상품 코드

    @Column(nullable = false, length = 50)
    private String itemNm; //상품명

    @Column(name="price",nullable = false)
    private int price; //가격

    @Column(nullable = false)
    private int stockNumber; //재고수량

    @Lob
    @Column(nullable = false)
    private String itemDetail; //상품 상세 설명

    @Enumerated(EnumType.STRING)
    private ItemSellStatus itemSellStatus; //상품 판매 상태


    @Enumerated(EnumType.STRING)
    private ItemUseability itemUseability = ItemUseability.ABLE; //상품 삭제 여부 디폴트 값은 사용 가능


//    아이템이 지워지면 그와 관련된 이미지 정보도 같이 지워짐
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemImg> itemImg;

//    아이템이 지워지면 그와 관련된 카트에 내용물도 같이 지워짐
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CartItem> cartItems;

//    아이템이 지워지면 그와 관련된 구매이력에 내용물도 같이 지워짐
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> orderItems;



}
