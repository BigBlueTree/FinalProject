package com.blue.bluearchive.admin.controller;

import com.blue.bluearchive.admin.dto.CategoryDto;
import com.blue.bluearchive.admin.entity.Category;
import com.blue.bluearchive.admin.service.CategoryService;
import com.blue.bluearchive.board.dto.BoardDto;
import com.blue.bluearchive.board.service.BoardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.util.List;
import java.util.NoSuchElementException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
@Slf4j
public class AdminController {
    private final CategoryService categoryService;
    private final BoardService boardService;

    @GetMapping("/main")
    public String adminMain() {
        return "adminPage/manageMain";
    }

    @GetMapping("/userMgt")
    public String userMgt() {
        return "adminPage/manageUser";
    }

    @GetMapping("/shopMgt")
    public String shopMgt() {
        return "adminPage/manageShop";
    }

    @GetMapping("/sellUserMgt")
    public String sellUserMgt() {
        return "/adminPage/manageUserSell";
    }

@GetMapping("/boardMgt")
public String boardMgt(Model model, @RequestParam(value = "categoryId", defaultValue = "0") int categoryId) {
        List<CategoryDto> categoryDtoList = categoryService.getAllCategory();
    List<BoardDto> boardDtoList;

    if (categoryId == 0) {
        // Fetch all boards
        boardDtoList = boardService.getAllBoards();
    } else {
        // Fetch boards by category ID
        boardDtoList = boardService.getBoardsByCategoryId(categoryId);
    }
    model.addAttribute("categoryList", categoryDtoList);
    model.addAttribute("boardDtoList", boardDtoList);
    return "/adminPage/manageCommunity_board2"; // boardMgt.html 페이지를 렌더링하여 반환
}
    @GetMapping("/boardMgt2")
    public String boardMgt(Model model, @RequestParam(value = "search") String search,
                           @RequestParam(value = "keyword")String keyword) {
        List<CategoryDto> categoryDtoList = categoryService.getAllCategory();

        List<BoardDto> boardDtoList = boardService.searchBoards(search,keyword);
        if (boardDtoList.isEmpty()) {
            model.addAttribute("message", "해당 게시글이 존재하지 않습니다.");
        }
        model.addAttribute("categoryList", categoryDtoList);
        model.addAttribute("boardDtoList", boardDtoList);
        return "/adminPage/manageCommunity_board2"; // boardMgt.html 페이지를 렌더링하여 반환
    }

    @GetMapping("/commentMgt")
    public String commentMgt() {
        return "/adminPage/manageCommunity_comment";
    }

    @GetMapping("/newcategory")
    public String newCate() {
        return "adminPage/newCategory";
    }

    @GetMapping("/commMgt")
    public String commMgt(Model model) {
        List<CategoryDto> categoryStatisticsList = categoryService.getTotal();
        model.addAttribute("categoryStatisticsList", categoryStatisticsList);
        return "adminPage/manageCommunity";
    }

    @PostMapping("/createCate")
    public String newCate(@ModelAttribute CategoryDto categoryDto) throws Exception {
        try {
            categoryService.save(categoryDto);
            return "redirect:/admin/commMgt";

        } catch (IllegalArgumentException e) {
            return "redirect:/admin/newcategory?duplicateError&categoryName=" + URLEncoder.encode(categoryDto.getCategoryName(), "UTF-8");
        }
    }

    @GetMapping("delete/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable int id) {
        try {
            categoryService.delete(id);
            return ResponseEntity.ok().build();
        } catch (NoSuchElementException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/update/{id}")
    public String categoryUpdate(@PathVariable int id, Model model) {
        Category categoryDto = categoryService.getCategoryById(id);
        model.addAttribute("categoryDto", categoryDto);
        return "adminPage/categoryUpdate";
    }

    @PostMapping("/updateCategory")
    public String categoryUpdate(@ModelAttribute CategoryDto categoryDto) throws Exception {
        try {
            categoryService.update(categoryDto);
            return "redirect:/admin/commMgt";
        } catch (IllegalArgumentException e) {
            return "redirect:/admin/update/" + categoryDto.getCategoryId()
                    + "?duplicateError&categoryName=" + URLEncoder.encode(categoryDto.getCategoryName(), "UTF-8");
        }
    }
}