package com.blue.bluearchive.board.repository.formRepository;

import com.blue.bluearchive.board.entity.CategoryActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryActivityRepository extends JpaRepository<CategoryActivity,Integer> {
}
