package com.blue.bluearchive.userpage.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserMainLogDataDto {
    private int categoryCount;
    private String logTime;
}
